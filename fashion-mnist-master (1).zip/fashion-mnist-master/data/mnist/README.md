# Downloading the MNIST dataset

http://yann.lecun.com/exdb/mnist/